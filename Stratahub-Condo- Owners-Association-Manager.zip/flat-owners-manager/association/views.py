import csv
from datetime import date

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.translation import gettext as _

from . import services
from .forms import ExpenseForm
from .models import CommitteeTerm, Expense, Flat, ServiceCharge


def _parse_month(value):
    try:
        y, m = (int(x) for x in value.split("-"))
        return date(y, m, 1)
    except (ValueError, AttributeError):
        return date.today().replace(day=1)


def _require_staff(request):
    if not request.user.is_staff:
        raise PermissionDenied


@login_required
def dashboard(request):
    month = date.today().replace(day=1)
    charges = ServiceCharge.objects.filter(month=month)
    collected = sum(c.amount for c in charges if c.is_paid)
    pending = sum(c.amount for c in charges if not c.is_paid)
    return render(request, "association/dashboard.html", {
        "month": month,
        "collected": collected,
        "pending": pending,
        "balance": services.current_balance(),
        "flat_count": Flat.objects.count(),
        "defaulter_count": services.defaulters(date.today()).count(),
    })


@login_required
def flat_list(request):
    flats = Flat.objects.select_related("owner")
    return render(request, "association/flats.html", {"flats": flats})


@login_required
def charge_list(request):
    month = _parse_month(request.GET.get("month") or request.POST.get("month"))
    if request.method == "POST":
        _require_staff(request)
        if "generate" in request.POST:
            n = services.generate_monthly_charges(month)
            messages.success(request, _("%(n)d charges generated.") % {"n": n})
        elif "pay" in request.POST:
            get_object_or_404(ServiceCharge, pk=request.POST["pay"]).mark_paid()
            messages.success(request, _("Payment recorded."))
        return redirect(f"{reverse('charges')}?month={month:%Y-%m}")
    charges = ServiceCharge.objects.filter(month=month).select_related("flat", "flat__owner")
    return render(request, "association/charges.html", {"charges": charges, "month": month})


@login_required
def receipt(request, pk):
    charge = get_object_or_404(ServiceCharge.objects.select_related("flat", "flat__owner"), pk=pk)
    if not charge.is_paid:
        messages.error(request, _("This charge has not been paid yet."))
        return redirect("charges")
    return render(request, "association/receipt.html", {"charge": charge})


@login_required
def ledger(request):
    if request.method == "POST":
        _require_staff(request)
        form = ExpenseForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, _("Expense added."))
            return redirect("ledger")
    else:
        form = ExpenseForm()
    return render(request, "association/ledger.html",
                  {"form": form, "expenses": Expense.objects.all()[:100]})


@login_required
def report(request):
    try:
        year = int(request.GET.get("year", date.today().year))
    except ValueError:
        year = date.today().year
    rows = services.monthly_summary(year)
    return render(request, "association/report.html", {
        "year": year,
        "rows": rows,
        "total_income": sum(r["income"] for r in rows),
        "total_expense": sum(r["expense"] for r in rows),
        "categories": services.category_breakdown(year),
        "defaulters": services.defaulters(date.today()),
        "balance": services.current_balance(),
    })


@login_required
def committee(request):
    terms = CommitteeTerm.objects.prefetch_related("members__owner")
    return render(request, "association/committee.html", {"terms": terms})


@login_required
def export_charges_csv(request):
    month = _parse_month(request.GET.get("month"))
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="charges-{month:%Y-%m}.csv"'
    response.write("\ufeff")  # BOM so Excel reads Bengali text correctly
    w = csv.writer(response)
    w.writerow(["flat", "owner", "month", "amount", "paid_on", "receipt_no"])
    for c in ServiceCharge.objects.filter(month=month).select_related("flat", "flat__owner"):
        w.writerow([c.flat.number, c.flat.owner or "", f"{c.month:%Y-%m}",
                    c.amount, c.paid_on or "", c.receipt_no])
    return response


@login_required
def export_expenses_csv(request):
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="expenses.csv"'
    response.write("\ufeff")
    w = csv.writer(response)
    w.writerow(["date", "category", "description", "amount"])
    for e in Expense.objects.all():
        w.writerow([e.date, e.category, e.description, e.amount])
    return response

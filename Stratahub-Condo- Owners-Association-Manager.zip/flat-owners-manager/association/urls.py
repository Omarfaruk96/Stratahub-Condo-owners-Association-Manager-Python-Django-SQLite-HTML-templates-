from django.urls import path

from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("flats/", views.flat_list, name="flats"),
    path("charges/", views.charge_list, name="charges"),
    path("charges/<int:pk>/receipt/", views.receipt, name="receipt"),
    path("charges/export.csv", views.export_charges_csv, name="export_charges"),
    path("ledger/", views.ledger, name="ledger"),
    path("ledger/export.csv", views.export_expenses_csv, name="export_expenses"),
    path("report/", views.report, name="report"),
    path("committee/", views.committee, name="committee"),
]

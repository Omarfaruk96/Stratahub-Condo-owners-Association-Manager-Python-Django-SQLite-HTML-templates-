"""Fill the database with FAKE demo data (never use real residents' data)."""
import random
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from association import services
from association.models import (CommitteeMember, CommitteeTerm, Expense, Flat,
                                Owner, ServiceCharge)

NAMES = ["Rahim Uddin", "Karim Hossain", "Nasrin Akter", "Sabbir Ahmed", "Farhana Islam",
         "Tanvir Rahman", "Mitu Begum", "Jahid Hasan", "Shirin Sultana", "Arif Chowdhury",
         "Rumana Haque", "Imran Khan"]


class Command(BaseCommand):
    help = "Create fake demo data and a demo admin user (admin / admin12345)."

    def handle(self, *args, **opts):
        random.seed(7)
        User = get_user_model()
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@example.com", "admin12345")
        if not User.objects.filter(username="owner").exists():
            User.objects.create_user("owner", password="owner12345")  # read-only role

        owners = [Owner.objects.get_or_create(name=n, defaults={"phone": f"01700-0000{i:02d}"})[0]
                  for i, n in enumerate(NAMES)]
        for i, owner in enumerate(owners):
            Flat.objects.get_or_create(
                number=f"{chr(65 + i // 4 + 0)}{(i % 4) + 1}0{i % 3 + 1}"[:4],
                defaults={"floor": i // 4 + 1, "owner": owner,
                          "monthly_charge": Decimal(2500 + 500 * (i % 3)),
                          "status": random.choice(list(Flat.Status.values))},
            )

        today = date.today().replace(day=1)
        for back in range(6, -1, -1):
            month = (today - timedelta(days=30 * back)).replace(day=1)
            services.generate_monthly_charges(month)
            for charge in ServiceCharge.objects.filter(month=month, paid_on__isnull=True):
                if back > 0 and random.random() < 0.85:
                    charge.mark_paid(month + timedelta(days=random.randint(2, 20)))
            if not Expense.objects.filter(date__year=month.year, date__month=month.month).exists():
                for cat, desc, amt in [("security", "Guard salaries", 12000), ("cleaning", "Cleaner", 6000),
                                       ("utilities", "Common area electricity", 4500),
                                       ("lift", "Lift service contract", 3000)]:
                    Expense.objects.create(date=month + timedelta(days=5), category=cat,
                                           description=desc, amount=amt)

        term, _ = CommitteeTerm.objects.get_or_create(
            title="Executive Committee", defaults={
                "start_date": date(today.year, 1, 1), "end_date": date(today.year + 1, 12, 31)})
        if not term.members.exists():
            for owner, pos in zip(owners, ["president", "vice_president", "secretary", "treasurer", "member"]):
                CommitteeMember.objects.create(term=term, owner=owner, position=pos)
        self.stdout.write(self.style.SUCCESS("Demo data ready. Log in with admin / admin12345"))

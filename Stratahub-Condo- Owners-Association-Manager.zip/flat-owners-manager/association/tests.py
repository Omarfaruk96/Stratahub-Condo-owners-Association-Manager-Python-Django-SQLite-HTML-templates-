from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from . import services
from .models import Expense, Flat, Owner, ServiceCharge

User = get_user_model()


class ServiceTests(TestCase):
    def setUp(self):
        owner = Owner.objects.create(name="Test Owner")
        Flat.objects.create(number="A101", floor=1, owner=owner, monthly_charge=2500)
        Flat.objects.create(number="A102", floor=1, monthly_charge=3000)

    def test_generate_is_idempotent(self):
        month = date(2026, 3, 15)
        self.assertEqual(services.generate_monthly_charges(month), 2)
        self.assertEqual(services.generate_monthly_charges(month), 0)
        self.assertEqual(ServiceCharge.objects.count(), 2)
        self.assertTrue(all(c.month == date(2026, 3, 1) for c in ServiceCharge.objects.all()))

    def test_mark_paid_assigns_receipt_once(self):
        services.generate_monthly_charges(date(2026, 3, 1))
        c = ServiceCharge.objects.first()
        c.mark_paid(date(2026, 3, 5))
        first = c.receipt_no
        self.assertTrue(first.startswith("R-202603-"))
        c.mark_paid(date(2026, 4, 1))  # second call must not change anything
        self.assertEqual(c.receipt_no, first)
        self.assertEqual(c.paid_on, date(2026, 3, 5))

    def test_monthly_summary_and_balance(self):
        services.generate_monthly_charges(date(2026, 3, 1))
        for c in ServiceCharge.objects.all():
            c.mark_paid(date(2026, 3, 10))
        Expense.objects.create(date=date(2026, 3, 12), category="security",
                               description="Guards", amount=1000)
        march = services.monthly_summary(2026)[2]
        self.assertEqual(march["income"], Decimal("5500"))
        self.assertEqual(march["expense"], Decimal("1000"))
        self.assertEqual(march["net"], Decimal("4500"))
        self.assertEqual(services.current_balance(), Decimal("4500"))

    def test_defaulters_only_unpaid(self):
        services.generate_monthly_charges(date(2026, 3, 1))
        ServiceCharge.objects.first().mark_paid(date(2026, 3, 5))
        self.assertEqual(services.defaulters(date(2026, 4, 1)).count(), 1)


class ViewTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user("boss", password="x", is_staff=True)
        self.viewer = User.objects.create_user("viewer", password="x")
        Flat.objects.create(number="A101", monthly_charge=2500)
        services.generate_monthly_charges(date.today())

    def test_login_required(self):
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.status_code, 302)
        self.assertIn("/accounts/login/", r["Location"])

    def test_viewer_can_read_but_not_pay(self):
        self.client.login(username="viewer", password="x")
        self.assertEqual(self.client.get(reverse("charges")).status_code, 200)
        charge = ServiceCharge.objects.first()
        r = self.client.post(reverse("charges"), {"pay": charge.pk})
        self.assertEqual(r.status_code, 403)
        charge.refresh_from_db()
        self.assertFalse(charge.is_paid)

    def test_staff_can_pay_and_get_receipt(self):
        self.client.login(username="boss", password="x")
        charge = ServiceCharge.objects.first()
        self.client.post(reverse("charges"), {"pay": charge.pk})
        charge.refresh_from_db()
        self.assertTrue(charge.is_paid)
        self.assertEqual(self.client.get(reverse("receipt", args=[charge.pk])).status_code, 200)

    def test_all_pages_render(self):
        self.client.login(username="boss", password="x")
        for name in ["dashboard", "flats", "charges", "ledger", "report", "committee",
                     "export_charges", "export_expenses"]:
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

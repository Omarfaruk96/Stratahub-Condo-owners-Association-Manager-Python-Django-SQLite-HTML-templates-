from datetime import date

from django.db import models
from django.utils.translation import gettext_lazy as _


class Owner(models.Model):
    name = models.CharField(_("Name"), max_length=120)
    phone = models.CharField(_("Phone"), max_length=30, blank=True)
    email = models.EmailField(_("Email"), blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Flat(models.Model):
    class Status(models.TextChoices):
        OWNER_OCCUPIED = "owner", _("Owner-occupied")
        RENTED = "rented", _("Rented")
        VACANT = "vacant", _("Vacant")

    number = models.CharField(_("Flat number"), max_length=10, unique=True)
    floor = models.PositiveSmallIntegerField(_("Floor"), default=1)
    owner = models.ForeignKey(
        Owner, verbose_name=_("Owner"), null=True, blank=True,
        on_delete=models.SET_NULL, related_name="flats",
    )
    status = models.CharField(
        _("Status"), max_length=10, choices=Status.choices, default=Status.OWNER_OCCUPIED
    )
    monthly_charge = models.DecimalField(
        _("Monthly service charge"), max_digits=10, decimal_places=2, default=0
    )

    class Meta:
        ordering = ["floor", "number"]

    def __str__(self):
        return self.number


class ServiceCharge(models.Model):
    flat = models.ForeignKey(Flat, on_delete=models.CASCADE, related_name="charges")
    month = models.DateField(_("Month"), help_text=_("Always the first day of the month"))
    amount = models.DecimalField(_("Amount"), max_digits=10, decimal_places=2)
    paid_on = models.DateField(_("Paid on"), null=True, blank=True)
    receipt_no = models.CharField(_("Receipt no."), max_length=30, blank=True)

    class Meta:
        ordering = ["-month", "flat__floor", "flat__number"]
        constraints = [
            models.UniqueConstraint(fields=["flat", "month"], name="one_charge_per_flat_month")
        ]

    def __str__(self):
        return f"{self.flat} - {self.month:%Y-%m}"

    @property
    def is_paid(self):
        return self.paid_on is not None

    def mark_paid(self, on=None):
        if self.is_paid:
            return
        self.paid_on = on or date.today()
        self.receipt_no = f"R-{self.month:%Y%m}-{self.pk:05d}"
        self.save(update_fields=["paid_on", "receipt_no"])


class Expense(models.Model):
    class Category(models.TextChoices):
        SECURITY = "security", _("Security")
        CLEANING = "cleaning", _("Cleaning")
        LIFT = "lift", _("Lift maintenance")
        UTILITIES = "utilities", _("Utilities")
        REPAIRS = "repairs", _("Repairs")
        OTHER = "other", _("Other")

    date = models.DateField(_("Date"), default=date.today)
    category = models.CharField(_("Category"), max_length=12, choices=Category.choices)
    description = models.CharField(_("Description"), max_length=200)
    amount = models.DecimalField(_("Amount"), max_digits=10, decimal_places=2)

    class Meta:
        ordering = ["-date", "-id"]

    def __str__(self):
        return f"{self.date} {self.description}"


class CommitteeTerm(models.Model):
    title = models.CharField(_("Title"), max_length=120)
    start_date = models.DateField(_("Start date"))
    end_date = models.DateField(_("End date"))

    class Meta:
        ordering = ["-start_date"]

    def __str__(self):
        return self.title

    @property
    def is_current(self):
        return self.start_date <= date.today() <= self.end_date


class CommitteeMember(models.Model):
    class Position(models.TextChoices):
        PRESIDENT = "president", _("President")
        VICE_PRESIDENT = "vice_president", _("Vice President")
        SECRETARY = "secretary", _("General Secretary")
        TREASURER = "treasurer", _("Treasurer")
        MEMBER = "member", _("Member")

    term = models.ForeignKey(CommitteeTerm, on_delete=models.CASCADE, related_name="members")
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE, related_name="positions")
    position = models.CharField(_("Position"), max_length=16, choices=Position.choices)

    class Meta:
        ordering = ["term", "id"]

    def __str__(self):
        return f"{self.owner} - {self.get_position_display()}"

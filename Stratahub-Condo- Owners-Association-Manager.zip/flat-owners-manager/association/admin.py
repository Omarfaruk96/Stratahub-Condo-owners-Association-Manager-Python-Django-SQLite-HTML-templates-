from django.contrib import admin

from .models import (CommitteeMember, CommitteeTerm, Expense, Flat, Owner,
                     ServiceCharge)


class MemberInline(admin.TabularInline):
    model = CommitteeMember
    extra = 1


@admin.register(CommitteeTerm)
class CommitteeTermAdmin(admin.ModelAdmin):
    list_display = ("title", "start_date", "end_date")
    inlines = [MemberInline]


@admin.register(Flat)
class FlatAdmin(admin.ModelAdmin):
    list_display = ("number", "floor", "owner", "status", "monthly_charge")
    list_filter = ("status", "floor")
    search_fields = ("number", "owner__name")


@admin.register(Owner)
class OwnerAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "email")
    search_fields = ("name", "phone")


@admin.register(ServiceCharge)
class ServiceChargeAdmin(admin.ModelAdmin):
    list_display = ("flat", "month", "amount", "paid_on", "receipt_no")
    list_filter = ("month",)


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("date", "category", "description", "amount")
    list_filter = ("category",)

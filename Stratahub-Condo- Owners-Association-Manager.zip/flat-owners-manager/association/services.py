from datetime import date
from decimal import Decimal

from django.db.models import Sum

from .models import Expense, Flat, ServiceCharge


def generate_monthly_charges(month: date) -> int:
    """Create a charge for every flat that does not yet have one for `month`.
    Safe to call repeatedly. Returns the number of charges created."""
    month = month.replace(day=1)
    existing = set(
        ServiceCharge.objects.filter(month=month).values_list("flat_id", flat=True)
    )
    new = [
        ServiceCharge(flat=f, month=month, amount=f.monthly_charge)
        for f in Flat.objects.all()
        if f.pk not in existing
    ]
    ServiceCharge.objects.bulk_create(new)
    return len(new)


def _total(qs):
    return qs.aggregate(t=Sum("amount"))["t"] or Decimal("0")


def monthly_summary(year: int):
    """Cash-basis income (by paid date) vs expenses for each month of `year`."""
    rows = []
    for m in range(1, 13):
        income = _total(ServiceCharge.objects.filter(paid_on__year=year, paid_on__month=m))
        expense = _total(Expense.objects.filter(date__year=year, date__month=m))
        rows.append({"month": date(year, m, 1), "income": income,
                     "expense": expense, "net": income - expense})
    return rows


def category_breakdown(year: int):
    return list(
        Expense.objects.filter(date__year=year)
        .values("category").annotate(total=Sum("amount")).order_by("-total")
    )


def current_balance() -> Decimal:
    return _total(ServiceCharge.objects.filter(paid_on__isnull=False)) - _total(
        Expense.objects.all()
    )


def defaulters(as_of: date):
    return (
        ServiceCharge.objects.filter(paid_on__isnull=True, month__lte=as_of)
        .select_related("flat", "flat__owner")
        .order_by("flat__floor", "flat__number", "month")
    )
